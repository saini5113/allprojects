const express = require('express')
const  mongoose = require("mongoose")
const expressLayouts = require('express-ejs-layouts')
const UserRouters = require('./routes/user')
const Article=require('./models/articals')


const app = express()

mongoose.connect('mongodb://127.0.0.1:27017/yourblog')

app.use(expressLayouts);
app.set('view engine','ejs');
app.use(express.static('public'))
app.use(express.json());
app.use(express.urlencoded({extended:true}))





app.get('/',async(req,res)=>{
    const articale = await Article.find();
    res.render('index',{article:articale})
})

app.use('/article',UserRouters)


const PORT = process.env.PORT || 8000
app.listen(PORT,()=>{
    console.log("ready")
})