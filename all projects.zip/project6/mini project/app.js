const express = require('express')
const path = require('path')
const request = require('request')

const app = express();


app.use(express.urlencoded({extended:true}))

app.get('/',(req, res)=>{
    res.sendFile(path.join(__dirname, './mini_project.html'))

})
app.post('/',(req,res)=>{
    const username = req.body.username
    const usermail = req.body.usermail;
    console.log(username,usermail);



    const option = {
        method :'POST',
        url: 'https://api.omnisend.com/v3/contacts',
        headers:{
            accept: 'application/json',
            'content-type': 'application/json',
            'X-API-KEY': '6388577b34e7ef8c426d2819-X3SL6TMWgZZAXLf2Svugyb5BuHZIDT3Ye2uZUJq5UghTDQUVqx'
        },
        body:{
            identifiers:[
                {
                    channels:{email:{status:'subscribed'}},
                    type : 'email',
                    id : usermail
                }
            ],
      firstname : username
    },
    json:true
};
    request(option,(error,response,body)=>{
        if(error) 
        {
            throw new Error(error);
        }

        
        res.sendFile(path.join(__dirname , './button.html'));
        
    })
})






app.listen(5000,()=>{
    console.log('started at 5000')
})








//6388577b34e7ef8c426d2819-X3SL6TMWgZZAXLf2Svugyb5BuHZIDT3Ye2uZUJq5UghTDQUVqx